//
//  MockSearchPresenter.swift
//  MyTravelHelperTests
//
//  Created by Sushil Kumar Singh on 01/03/20.
//  Copyright © 2021 Sample. All rights reserved.
//

import XCTest
@testable import MyTravelHelper
class MockSearchPresenter: InteractorToPresenterProtocol {

    var interactore:PresenterToInteractorProtocol!
    var stationListFetched:Bool = true
    var fetchedTrainsList:Bool = true

    func stationListFetched(list:[Station]){
        print("api is scessfully")
        stationListFetched = true
    }
    func fetchedTrainsList(trainsList:[StationTrain]?){
        fetchedTrainsList = true
    }
    func showNoTrainAvailbilityFromSource(){}
    func showNoInterNetAvailabilityMessage(){}
}

