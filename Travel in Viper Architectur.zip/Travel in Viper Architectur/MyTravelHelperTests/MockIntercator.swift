//
//  MockIntercator.swift
//  MyTravelHelperTests
//
//  Created by Sushil Kumar Singh on 01/03/20.
//  Copyright © 2021 Sample. All rights reserved.
//

import XCTest
@testable import MyTravelHelper
class MockIntercator: SearchTrainInteractor {
    override func fetchallStations() {
       super.fetchallStations()
    }
    override func fetchTrainsFromSource(sourceCode: String, destinationCode: String) {
    }
    override func addSearchTrainStationName(sourceAdress: String, distinationAdress: String) {
    }
}
