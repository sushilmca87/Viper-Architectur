//
//  MyTravelHelperTests.swift
//  MyTravelHelperTests
//
//  Created by Sushil Kumar Singh on 01/03/20.
//  Copyright © 2021 Sample. All rights reserved.
//

import XCTest
@testable import MyTravelHelper


class MyTravelHelperTests: XCTestCase {

    var favDao:FavoDao = FavoDao.sharedInstance
    var mockPresenter:MockSearchPresenter!
    var mockIntercator:MockIntercator!
    var searchTrainService:SearchTrainService!


    override func setUp() {
        super.setUp()
        mockPresenter = MockSearchPresenter()
        mockIntercator = MockIntercator()
        mockIntercator.presenter = mockPresenter
        mockPresenter.interactore = mockIntercator
        searchTrainService = SearchTrainService()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    func testOnFavoritesPresenter(){
          // perform Unit test on Favorites Table
           let info = FavoritesStation(sourceAdress: "BelFast", distinationAdress: "Lisburn")
           favDao.saveStationInfo(stationInfo: info)
           XCTAssertFalse(favDao.fetchAllFavoritesStation().isEmpty, "Data is not inserting in table")
    }
    func testFetchallStations(){
        print("found value")
        let promise = expectation(description: "Status code: 200")
        searchTrainService?.fetchAllStation({ (result) in
            switch result {
            case .success( _):
                promise.fulfill()
                XCTAssertTrue(self.mockPresenter.fetchedTrainsList, "Apo excuted sucessfull")
            case .failure(let error):
                XCTFail("Status code: \(error)")
            }
        })
        wait(for: [promise], timeout: 50)
    }
    func testFetchStation(){
         let promise = expectation(description: "Status code: 200")
        let sourceCode = "A149"
        searchTrainService?.fetchStation(sourceCode: sourceCode, completionHandle: { (resulte) in
            switch resulte {
            case .success( _):
                promise.fulfill()
                XCTAssertTrue(self.mockPresenter.stationListFetched, "Apo excuted sucessfull")
            case .failure(let error):
                XCTFail("Status code: \(error)")
            }
        })
       wait(for: [promise], timeout: 50)
    }
    func testSorceAndDestination(){
        let sourceCode = "Bangalore"
        let distination = "US"
        mockIntercator.fetchTrainsFromSource(sourceCode: sourceCode, destinationCode: distination)
        // then
        XCTAssertTrue(mockPresenter.fetchedTrainsList, "Input API excuted sucessfull")
    }

    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
   
    }
   
    func testUnitTestingOnFavoritesRealmTable(){
       //searchIntercator.addSearchTrainStationName(sourceAdress: "BelFast1", distinationAdress: "Lisburn1")

    }

    func testPerformanceExample() {
        // This is an example of a performance test case.
        measure {
            // Put the code you want to measure the time of here.
        }
    }

}
