//
//  SearchTrainInteractor.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 11/03/19.
//  Copyright © 2019 Sample. All rights reserved.
//

import Foundation
import XMLParsing
//import Alamofire

class SearchTrainInteractor: PresenterToInteractorProtocol {
    var _sourceStationCode = String()
    var _destinationStationCode = String()
    var presenter: InteractorToPresenterProtocol?
    var searchTrainService:SearchTrainService = SearchTrainService()
    
    func fetchallStations() {
            searchTrainService.fetchAllStation({ (result) in
                switch result {
                case .success(let stations):
                    self.presenter!.stationListFetched(list: stations)
                case .failure(let error):
                  self.presenter!.showNoInterNetAvailabilityMessage()
                }
            })
    }
    func addSearchTrainStationName(sourceAdress:String,distinationAdress:String){
        let stationInfo = FavoritesStation(sourceAdress: sourceAdress, distinationAdress: distinationAdress)
        FavoDao.sharedInstance.saveStationInfo(stationInfo: stationInfo)
    }

    func fetchTrainsFromSource(sourceCode: String, destinationCode: String) {
       
        _sourceStationCode = sourceCode
        _destinationStationCode = destinationCode
        searchTrainService.fetchStation(sourceCode: sourceCode) { (resulte) in
            switch resulte {
            case .success(let trainsList):
                if !trainsList.isEmpty {
                    self.proceesTrainListforDestinationCheck(trainsList: trainsList)
                }else{
                    self.presenter!.showNoTrainAvailbilityFromSource()
                }
            case .failure( _):
                self.presenter!.showNoTrainAvailbilityFromSource()
            }
        }
    }
    
    private func proceesTrainListforDestinationCheck(trainsList: [StationTrain]) {
        var _trainsList = trainsList
        let today = Date()
        let group = DispatchGroup()
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        let dateString = formatter.string(from: today)
        
        for index  in 0...trainsList.count-1 {
            group.enter()
            let _urlString = "http://api.irishrail.ie/realtime/realtime.asmx/getTrainMovementsXML?TrainId=\(trainsList[index].trainCode)&TrainDate=\(dateString)"
            if Reach().isNetworkReachable() {
                
                if let url = URL(string: _urlString) {
                    let request = URLRequest(url: url)
                    let task = URLSession.shared.dataTask(with: request) { data, response, error in
                        guard let movementsData = data, error == nil else {
                            print("error=\(String(describing: error))")
                            return
                        }
                        let trainMovements = try? XMLDecoder().decode(TrainMovementsData.self, from: movementsData)
                        if let _movements = trainMovements?.trainMovements {
                            let sourceIndex = _movements.firstIndex(where: {$0.locationCode.caseInsensitiveCompare(self._sourceStationCode) == .orderedSame})
                            let destinationIndex = _movements.firstIndex(where: {$0.locationCode.caseInsensitiveCompare(self._destinationStationCode) == .orderedSame})
                            let desiredStationMoment = _movements.filter{$0.locationCode.caseInsensitiveCompare(self._destinationStationCode) == .orderedSame}
                            let isDestinationAvailable = desiredStationMoment.count == 1
                            
                            if isDestinationAvailable  && sourceIndex! < destinationIndex! {
                                _trainsList[index].destinationDetails = desiredStationMoment.first
                            }
                        }
                        group.leave()
                    }
                    task.resume()
                }
                /*
                Alamofire.request(_urlString).response { (movementsData) in
                    let trainMovements = try? XMLDecoder().decode(TrainMovementsData.self, from: movementsData.data!)

                    if let _movements = trainMovements?.trainMovements {
                        let sourceIndex = _movements.firstIndex(where: {$0.locationCode.caseInsensitiveCompare(self._sourceStationCode) == .orderedSame})
                        let destinationIndex = _movements.firstIndex(where: {$0.locationCode.caseInsensitiveCompare(self._destinationStationCode) == .orderedSame})
                        let desiredStationMoment = _movements.filter{$0.locationCode.caseInsensitiveCompare(self._destinationStationCode) == .orderedSame}
                        let isDestinationAvailable = desiredStationMoment.count == 1

                        if isDestinationAvailable  && sourceIndex! < destinationIndex! {
                            _trainsList[index].destinationDetails = desiredStationMoment.first
                        }
                    }
                    group.leave()
                }
                */
            } else {
                self.presenter!.showNoInterNetAvailabilityMessage()
            }
        }

        group.notify(queue: DispatchQueue.main) {
            let sourceToDestinationTrains = _trainsList.filter{$0.destinationDetails != nil}
            self.presenter!.fetchedTrainsList(trainsList: sourceToDestinationTrains)
        }
    }
}
