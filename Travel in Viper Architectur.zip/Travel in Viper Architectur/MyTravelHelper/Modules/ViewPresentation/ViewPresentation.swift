//
//  ViewPresentation.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 01/03/20.
//  Copyright © 2021 Sample. All rights reserved.
//

import UIKit

protocol ViewPresentation: class {
       func viewDidLoad()
       func viewWillAppear()
       func viewWillDisapper()
}
