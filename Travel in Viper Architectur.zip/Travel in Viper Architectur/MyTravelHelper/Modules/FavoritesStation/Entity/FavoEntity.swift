//
//  FavoEntity.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 29/02/20.
//  Copyright © 2021 Sample. All rights reserved.
//

import UIKit
import RealmSwift
protocol RealmEntity {
    associatedtype ModelType
    var modelObject: ModelType { get }
}
protocol Entity {
    associatedtype RealmEntityType
    var realmObject: RealmEntityType { get }
}
class FavoEntity: Object,RealmEntity {
    typealias ModelType = FavoModel

    dynamic var sourceAddress:String?
    dynamic var distanationAddress:String?
    var modelObject: FavoModel {
        return FavoModel(favoEntity: self)
    }
}
extension FavoEntity {
    convenience init(model: ModelType) {
        self.init()
        self.sourceAddress = model.sourceAddress ?? self.sourceAddress
        self.distanationAddress = model.distanationAddress ?? self.distanationAddress
    }

}
