//
//  FavoritesModel.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 01/03/20.
//  Copyright © 2021 Sample. All rights reserved.
//

import UIKit
import RealmSwift

class FavoritesModel: Object {
   @objc dynamic var sourceAddress:String = ""
   @objc dynamic var distanationAddress:String = ""
}
