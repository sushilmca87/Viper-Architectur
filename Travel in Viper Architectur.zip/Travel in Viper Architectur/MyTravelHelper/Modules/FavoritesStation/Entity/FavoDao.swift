//
//  FavoDao.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 29/02/20.
//  Copyright © 2021 Sample. All rights reserved.
//

import UIKit
import RealmSwift


class FavoDao {
    static let   sharedInstance = FavoDao()
    private init() {}
    dynamic var sourceAddress:String?
    dynamic var distanationAddress:String?
    func saveStationInfo(stationInfo:FavoritesStation){
        let realm = try! Realm()
        let favorites = realm.objects(FavoritesModel.self).filter("sourceAddress contains[c] %@ && distanationAddress contains[c] %@",stationInfo.sourceAdress,stationInfo.distinationAdress)
        if let value = favorites.first {
            print("record found value:\(value)")
            self.deleted(object: value)
            self.saveStationInfo(stationInfo: stationInfo)
        }else{
             let favo = FavoritesModel()
             favo.sourceAddress = stationInfo.sourceAdress
             favo.distanationAddress = stationInfo.distinationAdress
             try! realm.write {
             realm.add(favo)
          }
        }
    }
    func deleted(object:Object){
        let realm = try! Realm()
        try! realm.write {
            print("deleted word: \(object)")
            realm.delete(object)
        }
    }
    func fetchAllFavoritesStation() ->[FavoritesModel]{
        let realm = try! Realm()
        var models:[FavoritesModel] = []
        let favorites = realm.objects(FavoritesModel.self)
        favorites.forEach { (model) in
            models.insert(model, at: 0)
        }
        print("models:\(models.count)")
        return models
    }
}
