//
//  FavoritesViewModel.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 01/03/20.
//  Copyright © 2021 Sample. All rights reserved.
//

import UIKit
struct FavoritesStation {
     var sourceAdress:String = ""
     var distinationAdress:String = ""
}
class FavoritesViewModel {
    var items:[FavoritesStation] = []
     init(data:[FavoritesModel]) {
        data.forEach { (model) in
            let stationInfo = FavoritesStation(sourceAdress: model.sourceAddress, distinationAdress: model.distanationAddress)
            items.append(stationInfo)
        }
    }
}

