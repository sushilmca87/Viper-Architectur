//
//  FavoritesViewController.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 29/02/20.
//  Copyright © 2021 Sample. All rights reserved.
//

import UIKit
protocol FavoritesSearchSelected:class {
    func favoritesSeatchSelected(info:FavoritesStation)
}
protocol FavoritesStationView : class {
    func updateFavorites(viewModel:FavoritesViewModel)
}
class FavoritesViewController: UIViewController {
        @IBOutlet weak var mTableView:UITableView!
        let identifier:String = "FavoriteStationCellId"
        var favoStationList:[FavoritesStation] = []
        var presenter:FavoStationPresentation?
       weak var favoritesDelegate:FavoritesSearchSelected?
        override func viewDidLoad() {
            super.viewDidLoad()
            self.presenter?.viewDidLoad()
            self.setupCell()
            self.presenter?.viewDidLoad()
            // Do any additional setup after loading the view.
        }
        func setupCell(){
            let nib = UINib(nibName: "FavoriteStationCell", bundle:nil)
            mTableView.register(nib, forCellReuseIdentifier: identifier)
        }
}
extension FavoritesViewController : UITableViewDataSource,UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return favoStationList.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: identifier, for: indexPath) as? FavoriteStationCell {
        cell.configureCell(info: favoStationList[indexPath.row])
        return cell
    }else {
        return FavoriteStationCell()
    }
  }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        favoritesDelegate?.favoritesSeatchSelected(info: favoStationList[indexPath.row])
    }
}
extension FavoritesViewController : FavoritesStationView {
    func updateFavorites(viewModel: FavoritesViewModel) {
        favoStationList = viewModel.items
        mTableView.reloadData()
    }
}
