//
//  FavoritePresenter.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 29/02/20.
//  Copyright © 2021 Sample. All rights reserved.
//

import UIKit
protocol FavoStationPresentation : ViewPresentation {
    func updateStationView()
}
class FavoritePresenter: NSObject,FavoStationPresentation {
    var interactor:FavoritesStationUseCase?
    weak var view:FavoritesStationView?
    func viewDidLoad() {
        self.interactor?.fetchFavoStation()
    }
    func viewWillAppear() {}
    func viewWillDisapper() {}
    func updateStationView(){
        print("need to update")
    }
}
extension FavoritePresenter: favoStationIntractorDelegate {
    func updateFavoritesStation(viewModel: FavoritesViewModel) {
        self.view?.updateFavorites(viewModel: viewModel)
    }
}
