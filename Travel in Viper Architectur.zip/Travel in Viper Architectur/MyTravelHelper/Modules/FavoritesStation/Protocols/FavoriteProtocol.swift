//
//  FavoriteProtocol.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 29/02/20.
//  Copyright © 2021 Sample. All rights reserved.
//

import UIKit

class FavoriteProtocol: NSObject {

}
