//
//  FavoriteInteractor.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 29/02/20.
//  Copyright © 2021 Sample. All rights reserved.
//

import UIKit
protocol favoStationIntractorDelegate :class {
    func updateFavoritesStation(viewModel: FavoritesViewModel)
}
class FavoriteInteractor: NSObject ,FavoritesStationUseCase{
    weak var delegate:favoStationIntractorDelegate?
    override init() {}
    func fetchFavoStation(){
             let  dndData = FavoDao.sharedInstance.fetchAllFavoritesStation()
             let viewModel = FavoritesViewModel(data: dndData)
             self.delegate?.updateFavoritesStation(viewModel: viewModel)
        }
}


