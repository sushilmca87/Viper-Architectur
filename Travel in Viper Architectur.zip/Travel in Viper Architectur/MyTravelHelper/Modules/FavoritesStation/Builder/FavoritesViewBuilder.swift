//
//  FavoritesViewBuilder.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 01/03/20.
//  Copyright © 2021 Sample. All rights reserved.
//

import UIKit
protocol MyTravelModuleBuilder {}
extension MyTravelModuleBuilder {
    static func assembleModule() -> UIViewController? {
        return nil
    }
}
class FavoritesViewBuilder: MyTravelModuleBuilder {
        static func assembleModule() -> UIViewController? {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        if let view = storyBoard.instantiateViewController(withIdentifier: "FavoritesViewControllerID") as? FavoritesViewController {
                    let presenter = FavoritePresenter()
                    let interactor = FavoriteInteractor()
                    view.presenter = presenter
                    presenter.view = view
                    presenter.interactor = interactor
                    interactor.delegate = presenter
                    return view
        }else{
           return nil
        }
    }
}
