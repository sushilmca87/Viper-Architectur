//
//  StationRouter.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 01/03/20.
//  Copyright © 2021 Sample. All rights reserved.
//

import UIKit

class StationRouter:NSObject {
        func showCall(viewControler:UIViewController) {
           if let dialerPadVC = FavoritesViewBuilder.assembleModule() as? FavoritesViewController, let favoritesView = viewControler as? SearchTrainViewController {
               favoritesView.addChild(dialerPadVC)
               dialerPadVC.view.frame = CGRect(x: 0, y: 0, width: favoritesView.view.frame.size.width, height: favoritesView.view.frame.size.height)
               favoritesView.view.addSubview(dialerPadVC.view)
                dialerPadVC.didMove(toParent: favoritesView)
               dialerPadVC.view.isHidden = true
           }
       }

}
