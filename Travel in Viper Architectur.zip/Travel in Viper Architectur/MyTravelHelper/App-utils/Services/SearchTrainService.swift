//
//  SearchTrainService.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 01/03/2021
//  Copyright © 2021 Sample. All rights reserved.
//

import UIKit
import XMLParsing
enum Failure :Error  {
    case NetworkNotReachable
    case FoundNil
}
class SearchTrainService {
    func fetchAllStation(_ completionHandler: @escaping((Result<[Station],Error>) -> Void)){
        if Reach().isNetworkReachable() == true {
        if let url = URL(string: "http://api.irishrail.ie/realtime/realtime.asmx/getAllStationsXML") {
            let request = URLRequest(url: url)
            let task = URLSession.shared.dataTask(with: request) { data, response, error in
                print("found response")
                guard let data = data, error == nil else {
                    print("error=\(String(describing: error))")
                    completionHandler(.failure(error!))
                    return
                }
                let station = try? XMLDecoder().decode(Stations.self, from: data)
                //self.presenter!.stationListFetched(list: station!.stationsList)
                completionHandler(.success(station!.stationsList))
            }
            task.resume()
        }
        }else{
            let error = Failure.FoundNil
            completionHandler(.failure(error))
        }
    }
    
    func fetchStation(sourceCode:String, completionHandle:@escaping((Result<[StationTrain],Error>)->Void)){
        let urlString = "http://api.irishrail.ie/realtime/realtime.asmx/getStationDataByCodeXML?StationCode=\(sourceCode)"
        if Reach().isNetworkReachable() {
            if let url = URL(string: urlString) {
                let request = URLRequest(url: url)
                let task = URLSession.shared.dataTask(with: request) { data, response, error in
                    guard let data = data, error == nil else {
                        print("error=\(String(describing: error))")
                        return
                    }
                    let stationData = try? XMLDecoder().decode(StationData.self, from: data)
                    if let _trainsList = stationData?.trainsList {
                        completionHandle(.success(_trainsList))
                    } else {
                        completionHandle(.success([]))
                    }
                }
                task.resume()
            }
        } else {
            completionHandle(.failure(Failure.FoundNil))
        }
    }
}
