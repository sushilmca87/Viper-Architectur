//
//  AppConstants.swift
//  MyTravelHelper
//
//  Created by Sushil Kumar Singh on 11/03/19.
//  Copyright © 2019 Sample. All rights reserved.
//

import Foundation

let PROGRESS_INDICATOR_VIEW_TAG: Int = 10
